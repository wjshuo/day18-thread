package com.lanou3g;

/**
 * Created by wubihang on 17/11/9.
 */
public class CountThread extends Thread {

    @Override
    public void run() {
        super.run();
        int count = 10;
        while (count > 0) {
            System.out.println("---->" + count);
            try {
                // 等待1秒
                Thread.sleep(1000);
                count--;
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

    }
}
