package com.lanou3g;

/**
 * Created by wubihang on 17/11/9.
 */
public class Main {
    public static void main(String[] args) {
        // 现在有2个功能要实现
        // 1.倒计时 10查到0  每一秒查一次
        // 2.输出字母1-100，每隔0.3秒输出1个

        // Thread.sleep(毫秒)
        // 线程休眠多少毫秒
        // 代码遇到该sleep就会等待多少毫秒

        // 继承Thread类的线程启动
        CountThread ct = new CountThread();
        ct.start();

        // 实现Runnable接口的线程启动
        CountRunnable cr = new CountRunnable();
        // 把线程任务 传入 线程的构造方法，构造出一个有任务的线程
        Thread t = new Thread(cr);
        t.start();
        
        // 最简单的创建线程方式
        // 匿名对象创建线程
        // 需要：Thread + run方法
        // 那些只需要执行一次就ok的任务
        new Thread(new Runnable() {
            @Override
            public void run() {

                for (int i = 0; i < 5; i++) {
                    System.out.println(i + "<-----");
                    try {
                        Thread.sleep(2000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                
            }
        }).start();
        



        // 利用线程的方法  sleep（毫秒）
//        int count = 10;
//        while (count > 0) {
//            System.out.println("倒" + count);
//             线程睡觉 1000毫秒
//            Thread.sleep(1000);
//            count--;
//        }

//        for (int i = 1; i < 100; i++) {
//            System.out.println("查" + i);
//            Thread.sleep(300);
//        }


    }
}
