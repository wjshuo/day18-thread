package com.lanou3g;

/**
 * Created by wubihang on 17/11/9.
 */
public class CountRunnable implements Runnable {

    @Override
    public void run() {
        int num = 1;
        while (num < 101){
            System.out.println(num);
            try {
                Thread.sleep(300);
                num++;
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
