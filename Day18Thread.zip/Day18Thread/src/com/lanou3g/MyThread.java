package com.lanou3g;

/**
 * Created by wubihang on 17/11/9.
 */
public class MyThread extends Thread{

    @Override
    public void run() {
        super.run();
        // 在run里写耗时操作，任务/功能的代码
        for (int i = 0; i < 300; i++) {
            // 打印线程名字和次数
            // currentThread返回当前线程对象，
            // getName 获取线程的名字
            String name = Thread.currentThread().getName();
            System.out.println(name+" "+i);
        }
    }
}
