package com.lanou3g.ticket;

/**
 * Created by wubihang on 17/11/9.
 */
public class SaleMain {
    public static void main(String[] args) {
        // 通过卖票问题讲解 线程的同步和锁

        // 12306客户端  - 线程
        // 12306网站   - 管理票信息
        // 主方法      - 开启线程，买票

        // 开始卖票，一共有500张票
        Ticket ticket = new Ticket();
        // 5个黄牛党开始抢票
        new Thread12306(ticket).start();
        new Thread12306(ticket).start();
        new Thread12306(ticket).start();
        new Thread12306(ticket).start();
        new Thread12306(ticket).start();

    }
}
