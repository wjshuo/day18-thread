package com.lanou3g.ticket;

/**
 * Created by wubihang on 17/11/9.
 */
public class Thread12306 extends Thread{

    private Ticket ticket;// 想要购买车次的票

    // 由构造方法传入
    public Thread12306(Ticket ticket){
        this.ticket = ticket;
    }

    @Override
    public void run() {

        while (true){
            boolean buyResult = ticket.buy();
//            if (buyResult == false){
            if (!buyResult){
                break;// 如果返回结果是false，
                // 证明没票了，停止购买
            }
        }

    }
}
