package com.lanou3g;

public class PrintCallback {
	private int num;// 当前打印的数字
	private String threadName;// 线程名称

	public PrintCallback() {
		super();
	}

	/**
	 * 打印线程数字 每轮打印5
	 * 
	 * @param threadName
	 *            线程名称
	 * **/
	public synchronized void callbackMethod(String threadName) {
		if (num <= 75) {
			// 每个线程打印5个数字
			for (int i = 0; i < 5; i++) {
				System.out.println(threadName + ":" + (++num));
			}
		}
	}

	/**
	 * 创建线程并启动线程
	 * 
	 * @exception InterruptedException
	 * **/
	public void printNum() throws InterruptedException {
		// 每个线程执行5个打印任务 3个线程轮询 所以得出外层是5层循环 内层是3层循环
		for (int i = 0; i < 5; i++) {// 75/3/5=5
			for (int j = 1; j < 4; j++) {// 创建3个线程
				threadName = "线程" + j;
				PrintThread runnable = new PrintThread(this);// 创建线程任务
				Thread thread = new Thread(runnable);// 创建一个真正的线程执行线程任务
				thread.setName(threadName);// 设置线程名称
				thread.start();// 启动线程
				thread.join();// 主线程需要等待子线程执行完毕
			}
		}
	}

	public static void main(String[] args) {
		try {
			PrintCallback pc = new PrintCallback();
			pc.printNum();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
