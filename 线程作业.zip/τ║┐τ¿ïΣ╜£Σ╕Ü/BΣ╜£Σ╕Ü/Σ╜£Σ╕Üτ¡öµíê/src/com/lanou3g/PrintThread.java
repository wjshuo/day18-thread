package com.lanou3g;

/**
 * 打印线程 持有线程回调对象
 * **/
public class PrintThread implements Runnable {
	private PrintCallback pCallback;

	public PrintThread(PrintCallback pCallback) {
		super();
		this.pCallback = pCallback;
	}

	@Override
	public void run() {
		pCallback.callbackMethod(Thread.currentThread().getName());// 执行任务
	}
}
