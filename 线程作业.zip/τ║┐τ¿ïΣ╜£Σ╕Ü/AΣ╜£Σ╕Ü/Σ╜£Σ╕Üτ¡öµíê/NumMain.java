
public class NumMain {

    public static void main(String[] args){
        // Thread启动
        NumThread numThread = new NumThread();
        numThread.start();

        // Runnable启动
        NumRunnable runnable = new NumRunnable();
        Thread thread = new Thread(runnable);

        thread.start();

    }
}
