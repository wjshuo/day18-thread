public class NumThread extends Thread{

    @Override
    public void run() {
        super.run();

        for (int i = 0; i < 100; i++) {
            try {
                Thread.sleep(1000);
                System.out.println(Thread.currentThread().getName()+"数字是："+i);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
