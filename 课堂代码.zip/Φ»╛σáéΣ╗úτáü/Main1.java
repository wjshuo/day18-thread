/**
 * Created by wubihang on 17/10/23.
 */
public class Main1 {

    public static void main(String[] args) {
        /*
        数组：存储相同数据类型元素的集合
        如：存10个整数，存10个字节，存储5个boolean

        数组也是一个变量

        1.数组的定义：
        一、无初始值，有容量（2种格式）

        二、有初始值 （2种格式）
         */

        // 存储10个整数的数组
        // 定义形式一
//        int [] nums = new int[10];
//        int num [] = new int[10];// C语言的写法

        // 定义形式二
        // 定义一个数组，存储5个具体的数
//        int [] a = {1,5,7,9,6};
//        int b [] = {88,99,66,44,101};

        // 定义数组，存储3个boolean类型数据
//        boolean [] isOrNo = new boolean[3];
        // 定义数组，存储a b c d e
//        char [] chars = {'a','b','c','d','e'};
        // 定义数组，存储真真假假
//        boolean[] bools ={true,true,false,false};


        // 2.数组的使用
        // 数组会对存入其中的元素进行编号
        // 从0开始，每一个元素都有一个位置（索引index下标）

        // 定义数组，容量为5，存储单精度小数
        float[] nums = new float[5];
        // 使用形式：按位置使用
        //  变量名 [位置] = 值
        nums[0] = 0.1f;
        nums[1] = 0.3f;
        nums[2] = 2.4f;
        nums[3] = 2.7f;
        nums[4] = 3.3f;
        System.out.println("-------");

        // 3.借助循环操作数组中的元素
        // 在数组被定义之后，JVM会帮助我们算好数组长度
        // 将数组长度以一个变量形式返回给开发者使用
        // length: 代表数组的长度（容量）
        // 使用方式：数组名.length
        for (int i = 0; i < nums.length;i++){
            System.out.print(nums[i] + "    ");
        }

        // 4.数组在定义完成并赋值后，也可以在此修改数组中的值
        // 借助 位置来实现
        // 如:现在要改变数组中第三个元素的值为3.14
        // 方式 数组名[位置] = 新值
        nums[2] = 3.14f;
        // 利用for循环打印数组，查看修改结果
        for (int i = 0; i < nums.length; i++) {
            System.out.print(nums[i] +"  ");
        }

        System.out.println("-----");
        
        
        // 5.数组越界问题
        // ArrayIndexOutOfBounds
        // 数组位置超出边界
        int [] n = new int[10];
        n[9] = 4;
        System.out.println(n[9]);

    }
}
