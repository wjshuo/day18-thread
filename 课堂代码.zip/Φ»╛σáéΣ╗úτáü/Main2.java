import java.util.Scanner;

/**
 * Created by wubihang on 17/10/23.
 */
public class Main2 {
    public static void main(String[] args) {
        // 1.输入5个数，存入数组
        // 利用for循环打印出数组中的5个数(横排打印)
//        int[] nums = new int[5];
//        Scanner scan = new Scanner(System.in);
//        // 执行5次：输入一个数，存入数组
//        for (int i = 0; i < 5; i++) {
//            System.out.println("输入一个数:");
//            nums[i] = scan.nextInt();
//        }
//        // 验证：打印数组
//        for (int i = 0; i < nums.length; i++) {
//            System.out.print(nums[i]+"  ");
//        }
//

        // 2.创建一个数组，存储5个小数
        // 输入5个小数存入数组，打印数组
        // - 创建小数数组，容量为5
        // - 创建Scanner输入5个小数，存入数组
        // - 打印数组

        // 3. 现有数组 {5,72,8,11,24 }
        // 找出其中的最大值和最小值
//        int [] aa = {5, 72, 8, 11, 24};
//        int max = 0;
//        int min = 100;
//        for (int i = 0; i < aa.length; i++) {
//            max = max > aa[i] ? max : aa[i];
//            min = min < aa[i] ? min : aa[i];
//        }
//        System.out.println("最大值是："+max);
//        System.out.println("最小值是:" + min);

//        for (int i = 0; i < aa.length; i++) {
//            if (aa[i] > max) {
//                max = aa[0];
//            } else {
//                max = max;
//            }
//        }




        // 两个数中的最大值
//        int a = 5, b = 7;
//        int max = 0;

//        max = a > b ? a : b;

//        if (a > b){
//            max = a;
//        } else {
//            max = b;
//        }
//        System.out.println(max);


        // 4.现有一数组 { 1，6，7，8}
        // 把首位的数 和 末位的数调换位置

        // - 利用支付宝例子调换数
        // - 首位可以使用0.末尾不可以使用3
//        int [] nums = {1, 6, 7, 8};
//        int temp;
//        temp = nums[0];
//        nums[0] = nums[nums.length - 1];
//        nums[nums.length - 1] = temp;
//
//        for (int i = 0; i < nums.length; i++) {
//            System.out.print(nums[i]+"  ");
//        }

        // 5.现有一整数数组
        // 1 8 0 6 5 9 6 5 8 9 5 8 0 6 7 0 6 5 0 6
        // 输出中间那个元素
//        int[] n = {1,8,8,7,6,4,3,45,67,56,6,6,7,9,24,34,65,87,45,23,32,8,23,34,5,56,56};
//        int index = n.length;
//        int halfIndex = index / 2;
//        System.out.println(n[halfIndex]);
//        System.out.println(n[n.length / 2]);

    }
}
