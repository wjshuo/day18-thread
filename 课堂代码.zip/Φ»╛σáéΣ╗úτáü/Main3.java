import java.util.Scanner;

/**
 * Created by wubihang on 17/10/23.
 */
public class Main3 {
    
    public static void main(String[] args){
    
        // 1.录入3个班级的成绩
//        for(int j = 0; j < 3; j++) {
//            int[] num1 = new int[5];
//            Scanner s = new Scanner(System.in);
//            System.out.println("请录入"+j+"班成绩");
//            for (int i = 0; i < num1.length; i++) {
//                System.out.println("第" + (i + 1) + "个同学：");
//                num1[i] = s.nextInt();
//            }
//        }
//        
        // 循环嵌套：
        // 循环里面 写 循环 
        // 执行流程：
        // 外层1次，内层循环一个周期
        // 外层2次，内层循环一个周期
        
        // 2.打印5行5列 * 号
//        for (int i = 0; i < 5; i++) {
//            for (int j = 0; j < 5; j++) {
//                System.out.print("*");
//            }
//            System.out.println();
//        }
        // 第一次  i=0,j=0-5
        // 第二次  i=1,j=0-5 
        // 第三次  i=2,j=0-5
        // 第四次  i=3,j=0-5
        // 第五次  i=4,j=0-5
        
        // 3.
       // *            i=0  -  j 0
       // * *          i=1  -  j 0-1
       // * * *        i=2  -  j 0-2 
       // * * * *      i=3  -  j 0-3
       // * * * * *    i=4  -  j 0-4
//        for (int i = 0; i < 5; i++) {
//          i=0  j=0;j<1
//          i=1  j=0;j<2   
//          i=2  j=0;j<3
//          i=3  j=0;j<4          
//            for (int j = 0; j < i+1; j++) {
//                System.out.print("*");
//            }
//            System.out.println();
//        }
        // 4.
        // * * * * *   i=0;  j=0;j<5;j++
        // * * * *     i=1;  j=1;j<5;j++
        // * * *       i=2;  j=2;j<5;j++
        // * *         i=3;  j=3;j<5;j++
        // *           i=4;  j=4;j<5;j++
//        int n = new Scanner(System.in).nextInt();
//        for (int i = 0; i < n; i++) {
//            for (int j = i; j < n; j++) {
//                System.out.print("*");
//            }
//            System.out.println();
//        }

        // 5.9行9列的*,在切掉一半
//        for (int i = 1; i < 10; i++) {
//            for (int j = 1; j < i+1; j++) {
//                System.out.print("*");
//            }
//            System.out.println();
//        }
        // 打印 99乘法表
//        for (int i = 1; i < 10; i++) {
//            for (int j = 1; j < i+1; j++) {
//                System.out.print(j+"*"+i+"="+(i*j)+"  ");
//            }
//            System.out.println();
//        }


        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 5; j++) {
                if (i == 2){
                    break;
                }
                System.out.print("  "+ j +"  ");
            }
            System.out.print("---->" + i);
            System.out.println();
        }
//    i=0    01234
//    i=1    01234
//    i=2
//    i=3    01234

    }
}
